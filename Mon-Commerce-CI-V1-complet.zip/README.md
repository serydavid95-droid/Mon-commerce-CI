# Mon Commerce CI — V1

Application Android de gestion simple pour petit commerce.

## Fonctions V1
- Tableau de bord
- Produits et stock
- Enregistrement des ventes
- Dettes clients
- Dépenses
- Alertes de stock faible
- Données conservées localement
- Compilation APK automatique avec GitHub Actions

## Compiler
Le workflow `.github/workflows/build-apk.yml` se lance automatiquement après un push sur `main`, ou manuellement depuis GitHub Actions.

L'APK debug est disponible dans les Artifacts du workflow.