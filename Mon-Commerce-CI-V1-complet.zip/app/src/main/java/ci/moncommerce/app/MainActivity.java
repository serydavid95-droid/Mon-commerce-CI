package ci.moncommerce.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView balance, salesCount, stockCount, debtCount;
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<Sale> sales = new ArrayList<>();
    ArrayList<Debt> debts = new ArrayList<>();
    android.content.SharedPreferences prefs;

    int blue = Color.rgb(21,101,192);
    int dark = Color.rgb(13,71,161);
    int green = Color.rgb(46,125,50);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("data", MODE_PRIVATE);
        loadData();
        showHome();
    }

    TextView tv(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(16,12,16,12);
        return t;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false);
        return b;
    }

    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,247,250));
        TextView bar = tv(title, 21, Color.WHITE);
        bar.setGravity(Gravity.CENTER_VERTICAL); bar.setBackgroundColor(dark);
        bar.setPadding(20,18,20,18);
        root.addView(bar, new LinearLayout.LayoutParams(-1,64));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER);
        String[] ns={"🏠 Accueil","📦 Stock","💰 Ventes","👥 Dettes"};
        for(String n:ns){ Button x=btn(n); nav.addView(x,new LinearLayout.LayoutParams(0,58,1));
            if(n.contains("Accueil")) x.setOnClickListener(v->showHome());
            if(n.contains("Stock")) x.setOnClickListener(v->showStock());
            if(n.contains("Ventes")) x.setOnClickListener(v->showSales());
            if(n.contains("Dettes")) x.setOnClickListener(v->showDebts());
        }
        root.addView(nav);
        setContentView(root);
    }

    TextView card(String label,String value) {
        TextView t=tv(label+"\n"+value,17,Color.DKGRAY);
        t.setBackgroundColor(Color.WHITE); t.setPadding(20,18,20,18);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,90); p.setMargins(12,8,12,8);
        content.addView(t,p); return t;
    }

    void showHome() {
        base("Mon Commerce CI");
        content.addView(tv("Tableau de bord",25,dark));
        balance=card("Chiffre d'affaires", money(totalSales()));
        salesCount=card("Nombre de ventes", ""+sales.size());
        stockCount=card("Produits en stock", ""+products.size());
        debtCount=card("Dettes clients", money(totalDebt()));
        Button add=btn("➕ Nouvelle vente"); content.addView(add); add.setOnClickListener(v->newSale());
        Button prod=btn("📦 Ajouter un produit"); content.addView(prod); prod.setOnClickListener(v->newProduct());
        Button dep=btn("💸 Ajouter une dépense"); content.addView(dep); dep.setOnClickListener(v->addExpense());
        content.addView(tv("Astuce : garde ton stock à jour pour voir automatiquement les alertes.",15,Color.GRAY));
    }

    void showStock() {
        base("Gestion du stock");
        Button add=btn("➕ Ajouter un produit"); content.addView(add); add.setOnClickListener(v->newProduct());
        if(products.isEmpty()) content.addView(tv("Aucun produit. Ajoute ton premier produit.",18,Color.GRAY));
        for(Product p:products) {
            TextView t=tv("📦 "+p.name+"\nPrix: "+money(p.price)+"   Stock: "+p.stock+
                    (p.stock<=3?"  ⚠️ STOCK FAIBLE":""),17,Color.DKGRAY);
            t.setBackgroundColor(Color.WHITE); content.addView(t);
            Button row=btn("Vendre 1  •  Modifier stock");
            content.addView(row); row.setOnClickListener(v->newSaleFor(p));
        }
    }

    void showSales() {
        base("Ventes");
        content.addView(tv("Total : "+money(totalSales()),22,green));
        Button add=btn("➕ Enregistrer une vente"); content.addView(add); add.setOnClickListener(v->newSale());
        if(sales.isEmpty()) content.addView(tv("Aucune vente enregistrée.",18,Color.GRAY));
        for(Sale s:sales) content.addView(tv("💰 "+s.product+" — "+money(s.amount)+"\n"+s.date,16,Color.DKGRAY));
    }

    void showDebts() {
        base("Dettes clients");
        Button add=btn("➕ Ajouter une dette"); content.addView(add); add.setOnClickListener(v->newDebt());
        content.addView(tv("Total dû : "+money(totalDebt()),22,Color.rgb(198,40,40)));
        for(Debt d:debts) content.addView(tv("👤 "+d.client+" — "+money(d.amount)+"\n"+d.date,17,Color.DKGRAY));
    }

    void newProduct() {
        final EditText name=new EditText(this); name.setHint("Nom du produit");
        final EditText price=new EditText(this); price.setHint("Prix (FCFA)"); price.setInputType(2);
        final EditText stock=new EditText(this); stock.setHint("Stock initial"); stock.setInputType(2);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.addView(name); l.addView(price); l.addView(stock);
        new AlertDialog.Builder(this).setTitle("Nouveau produit").setView(l)
          .setPositiveButton("Enregistrer",(d,w)->{
              try { products.add(new Product(name.getText().toString(),Double.parseDouble(price.getText().toString()),Integer.parseInt(stock.getText().toString()))); saveData(); showStock(); }
              catch(Exception e){ toast("Vérifie les informations."); }
          }).setNegativeButton("Annuler",null).show();
    }

    void newSale() {
        if(products.isEmpty()){toast("Ajoute d'abord un produit."); return;}
        chooseProduct();
    }
    void newSaleFor(Product p) { recordSale(p); }

    void chooseProduct() {
        String[] names=new String[products.size()];
        for(int i=0;i<products.size();i++) names[i]=products.get(i).name+" — "+money(products.get(i).price);
        new AlertDialog.Builder(this).setTitle("Choisir un produit").setItems(names,(d,w)->recordSale(products.get(w))).show();
    }

    void recordSale(Product p) {
        if(p.stock<=0){toast("Stock épuisé."); return;}
        final EditText qty=new EditText(this); qty.setHint("Quantité"); qty.setInputType(2); qty.setText("1");
        new AlertDialog.Builder(this).setTitle("Vendre : "+p.name).setView(qty)
          .setPositiveButton("Valider",(d,w)->{
              try{
                int q=Integer.parseInt(qty.getText().toString());
                if(q<1 || q>p.stock){toast("Stock insuffisant."); return;}
                p.stock-=q; sales.add(new Sale(p.name,p.price*q)); saveData(); showSales();
              }catch(Exception e){toast("Quantité invalide.");}
          }).setNegativeButton("Annuler",null).show();
    }

    void newDebt() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        EditText c=new EditText(this); c.setHint("Nom du client");
        EditText a=new EditText(this); a.setHint("Montant (FCFA)"); a.setInputType(2);
        l.addView(c);l.addView(a);
        new AlertDialog.Builder(this).setTitle("Nouvelle dette").setView(l)
          .setPositiveButton("Enregistrer",(d,w)->{try{debts.add(new Debt(c.getText().toString(),Double.parseDouble(a.getText().toString())));saveData();showDebts();}catch(Exception e){toast("Vérifie le montant.");}})
          .setNegativeButton("Annuler",null).show();
    }

    void addExpense() {
        EditText a=new EditText(this); a.setHint("Montant de la dépense"); a.setInputType(2);
        new AlertDialog.Builder(this).setTitle("Dépense").setView(a)
          .setPositiveButton("Enregistrer",(d,w)->{try{double x=Double.parseDouble(a.getText().toString()); prefs.edit().putFloat("expenses",prefs.getFloat("expenses",0)+((float)x)).apply(); toast("Dépense enregistrée."); showHome();}catch(Exception e){toast("Montant invalide.");}})
          .setNegativeButton("Annuler",null).show();
    }

    double totalSales(){double x=0;for(Sale s:sales)x+=s.amount;return x;}
    double totalDebt(){double x=0;for(Debt d:debts)x+=d.amount;return x;}
    String money(double x){return String.format(Locale.US,"%.0f FCFA",x);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void saveData() {
        StringBuilder p=new StringBuilder();
        for(Product x:products)p.append(esc(x.name)).append("|").append(x.price).append("|").append(x.stock).append("\n");
        StringBuilder s=new StringBuilder();
        for(Sale x:sales)s.append(esc(x.product)).append("|").append(x.amount).append("|").append(esc(x.date)).append("\n");
        StringBuilder d=new StringBuilder();
        for(Debt x:debts)d.append(esc(x.client)).append("|").append(x.amount).append("|").append(esc(x.date)).append("\n");
        prefs.edit().putString("products",p.toString()).putString("sales",s.toString()).putString("debts",d.toString()).apply();
    }
    String esc(String x){return x.replace("|","/").replace("\n"," ");}
    void loadData(){
        String ps=prefs.getString("products",""); for(String z:ps.split("\n")){try{if(z.trim().isEmpty())continue;String[] a=z.split("\\|");products.add(new Product(a[0],Double.parseDouble(a[1]),Integer.parseInt(a[2])));}catch(Exception ignored){}}
        String ss=prefs.getString("sales",""); for(String z:ss.split("\n")){try{if(z.trim().isEmpty())continue;String[] a=z.split("\\|");sales.add(new Sale(a[0],Double.parseDouble(a[1]),a.length>2?a[2]:""));}catch(Exception ignored){}}
        String ds=prefs.getString("debts",""); for(String z:ds.split("\n")){try{if(z.trim().isEmpty())continue;String[] a=z.split("\\|");debts.add(new Debt(a[0],Double.parseDouble(a[1]),a.length>2?a[2]:""));}catch(Exception ignored){}}
    }

    static class Product {String name;double price;int stock;Product(String n,double p,int s){name=n;price=p;stock=s;}}
    static class Sale {String product,date;double amount;Sale(String p,double a){this(p,a,new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date()));}Sale(String p,double a,String d){product=p;amount=a;date=d;}}
    static class Debt {String client,date;double amount;Debt(String c,double a){this(c,a,new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date()));}Debt(String c,double a,String d){client=c;amount=a;date=d;}}
}